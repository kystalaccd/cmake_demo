var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
console.log('app.js_ start: ', '1,加载第三方框架完成');

var utils = require('./models/utils');
console.log('app.js_ start: ', '2,加载utils完成');

var indexRouter = require('./routes/index');
var deviceRouter = require('./routes/device');
var nvrRouter = require('./routes/nvr');
var recordRouter = require('./routes/record');
var mapRouter = require('./routes/map');
var codeRouter = require('./routes/code');
var upgradeRouter = require('./routes/upgrade');
console.log('app.js_ start: ', '4,加载路由模块完成');

var app = express();

// 配置跨域
app.all('*', function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*'); // 自定义中间件，设置跨域需要的响应头
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE'); // 允许任何方法
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,X-Session-Token'); // 允许任何类型
  if (req.method == 'OPTIONS')
    res.sendStatus(200); // 让options尝试请求快速结束
  else
    next();
});

// 路由请求超时的中间件
app.use(function (req, res, next) {
  // 这里必须是Response响应的定时器【15秒】
  res.setTimeout(15 * 1000, function () {
    console.log("Request has timed out.");
    return res.status(408).json({
      status: 408,
      msg: 'time_out'
    })
  });
  next();
});

// view engine setup
app.set('views', path.join(__dirname, '../web'));
// app.set('view engine', 'jade');

app.engine('.html', require('ejs').__express);
app.set('view engine', 'html');

app.use(logger('dev'));
app.use(express.json({limit: '50mb'}));
app.use(express.urlencoded({limit: '50mb', extended: false}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '../web')));

app.use('/', indexRouter);
app.use('/device', deviceRouter);
app.use('/nvr', nvrRouter);
app.use('/record', recordRouter);
app.use('/map', mapRouter);
app.use('/code', codeRouter);
app.use('/upgrade', upgradeRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

// //定时任务,当文件夹超过500MB时,给文件排序删除时间最长的文件
// utils.calcSize('../other', (err, size) => {
//   let sizeMb = 0;
//   if (err) {
//     console.log(err)
//   } else {
//     sizeMb = size / 1024 / 1024;
//     console.log("other文件夹大小：" + sizeMb.toFixed(3) + "Mb")
//   }
//
//   if (sizeMb > 500) {//500mb
//     // TODO 2022/11/1 16:11 大于500mb就清除图片?
//   }
// })


/**
 * Module dependencies.
 */

var debug = require('debug')('626-broadcast-server:server');
var http = require('http');

/**
 * Get port from environment and store in Express.
 */

var port = normalizePort(process.env.PORT || '5000');
app.set('port', port);

/**
 * Create HTTP server.
 */

var server = http.createServer(app);

/**
 * Listen on provided port, on all network interfaces.
 */

server.listen(port);
server.on('error', onError);
server.on('listening', onListening);

/**
 * Normalize a port into a number, string, or false.
 */

function normalizePort(val) {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
}

/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  var bind = typeof port === 'string'
      ? 'Pipe ' + port
      : 'Port ' + port;

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' requires elevated privileges');
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(bind + ' is already in use');
      process.exit(1);
      break;
    default:
      throw error;
  }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening() {
  var addr = server.address();
  var bind = typeof addr === 'string'
      ? 'pipe ' + addr
      : 'port ' + addr.port;
  debug('Listening on ' + bind);
}

var OnvifManager = require('./models/onvif');
OnvifManager.init();
console.log('app.js_ start: ', '6, onvif广播的ws连接打开');


console.log('http://127.0.0.1:5000')

module.exports = app;
