const fs = require('fs');

class codeManager {

    constructor() {

    }

    setData(codeData) { // 保存数据
        try {
            if (!codeData) {
                return false;
            }
            if (!fs.existsSync(`../other/users`)) {
                fs.mkdirSync(`../other/users`);
            }

            // let nowData = utils.readJsonFile('./json/codeData.json');


            fs.writeFileSync(`../other/users/codeData.json`, JSON.stringify(codeData));
            return true;
        } catch (e) {

            console.log('codeManager.js_ : ', e);
            return false;
        }
    }

    getData() { // 获取数据
        if (!fs.existsSync(`../other/users/codeData.json`)) {
            return '';
        }
        return fs.readFileSync(`../other/users/codeData.json`).toString();
    }

    setQRCodeData(QRCodeData) { // 保存数据
        try {
            if (!QRCodeData) {
                return false;
            }
            if (!fs.existsSync(`../other/picture`)) {
                fs.mkdirSync(`../other/picture`);
            }

            // let nowData = utils.readJsonFile('./json/codeData.json');


            fs.writeFileSync(`../other/picture/QRCodeData.json`, JSON.stringify(QRCodeData));
            return true;
        } catch (e) {

            console.log('codeManager.js_ : ', e);
            return false;
        }
    }

    getQRCodeData() { // 获取数据
        if (!fs.existsSync(`../other/picture/QRCodeData.json`)) {
            return '';
        }
        return fs.readFileSync(`../other/picture/QRCodeData.json`).toString();
    }
}

module.exports = new codeManager()