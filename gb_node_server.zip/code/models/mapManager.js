const fs = require('fs');

class mapManager {

    constructor() {

    }

    setData(mapData) { // 保存数据
        try {
            if (!mapData) {
                return false;
            }
            if (!fs.existsSync(`../other/users`)) {
                fs.mkdirSync(`../other/users`);
            }

            // let nowData = utils.readJsonFile('./json/mapData.json');


            fs.writeFileSync(`../other/users/mapData.json`, JSON.stringify(mapData));
            return true;
        } catch (e) {

            console.log('mapManager.js_ : ', e);
            return false;
        }
    }

    getData() { // 获取数据
        if (!fs.existsSync(`../other/users/mapData.json`)) {
            return '';
        }
        return fs.readFileSync(`../other/users/mapData.json`).toString();
    }
}

module.exports = new mapManager()