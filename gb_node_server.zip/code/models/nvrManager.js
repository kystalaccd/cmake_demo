const fs = require('fs');
const utils = require('./utils');

class nvrManager {

    constructor() {

    }

    save(nvrData) { // 保存数据
        try {
            if (nvrData == null) {
                return false;
            }
            if (!fs.existsSync(`../other/users`)) {
                fs.mkdirSync(`../other/users`);
            }
            fs.writeFileSync(`../other/users/nvrData.json`, JSON.stringify(nvrData));
            return true;
        } catch (e) {

            console.log('NvrManager.js_ : ', e);
            return false;
        }
    }

    getData() { // 获取数据
        if (!fs.existsSync(`../other/users/nvrData.json`)) {
            return '';
        }
        return fs.readFileSync(`../other/users/nvrData.json`).toString();
    }

    delete(ids) { // 删除数据
        try {
            if (utils.isEmpty(ids)) {
                return false;
            }
            if (!fs.existsSync(`../other/users/nvrData.json`)) {
                return false;
            }
            let nvrData = JSON.parse(fs.readFileSync(`../other/users/nvrData.json`).toString());

            for (let id of ids) {
                for (let i = nvrData.length - 1; i >= 0; i--) {
                    if (id === nvrData[i].id)
                        nvrData.splice(i, 1)
                }
            }

            fs.writeFileSync(`../other/users/nvrData.json`, JSON.stringify(nvrData));
            return true;
        } catch (e) {
            console.log('NvrManager.js_ : ', e);
            return false;
        }
    }
}

module.exports = new nvrManager()