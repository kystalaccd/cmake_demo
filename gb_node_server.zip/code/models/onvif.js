const http = require('http');
const WebSocketServer = require('websocket').server;
const onvif = require('node-onvif');

// var onvif = null;
// try {
//     onvif = require('./lib/node-onvif.js');
// } catch(e) {
//     onvif = require('node-onvif');
// }

const ws_port = 5001; // websocket服务端接收端口

var devices = {};

function wsServerRequest(request) {
    conn = request.accept(null, request.origin);
    conn.on("message", function(message) {
        if(message.type !== 'utf8') {
            return;
        }
        let data = JSON.parse(message.utf8Data);
        let method = data['method'];
        let params = data['params'];
        if(method === 'startDiscovery') {
            startDiscovery(conn);
        } else if(method === 'connect') {
            connect(conn, params);
        } else if(method === 'fetchSnapshot') {
            fetchSnapshot(conn, params);
        } else if(method === 'ptzMove') {
            ptzMove(conn, params);
        } else if(method === 'ptzStop') {
            ptzStop(conn, params);
        } else if(method === 'ptzHome') {
            ptzHome(conn, params);
        } else if(method === 'getPreset') {
            getPreset(conn, params);
        } else if(method === 'setPreset') {
            setPreset(conn, params);
        } else if(method === 'gotoPreset') {
            gotoPreset(conn, params);
        } else if(method === 'removePreset') {
            removePreset(conn, params);
        }
    });

    conn.on("close", function(message) {
        console.log(message);
    });
    conn.on("error", function(error) {
        console.log(error);
    });
}

function startDiscovery(conn) { // 获取局域网内摄像机信息
    devices = {};
    let names = {};
    onvif.startProbe().then((device_list) => {
        device_list.forEach((device) => {
            let onvif_device = new onvif.OnvifDevice({
                xaddr: device.xaddrs[0]
            });
            let addr = onvif_device.address;
            devices[addr] = onvif_device;
            names[addr] = device.name;
        });
        let devs = [];
        for (const addr in devices) {
            devs.push({
                name: names[addr],
                address: addr
            })
        }
        let res = {'id': 'startDiscovery', 'result': devs};
        conn.send(JSON.stringify(res));
    }).catch((error) => {
        let res = {'id': 'connect', 'error': error.message};
        conn.send(JSON.stringify(res));
    });
}

function connect(conn, params) { // 连接摄像机获取流信息和配置参数
    let device = devices[params.address];
    if(!device) {
        let res = {'id': 'connect', 'error': 'The specified device is not found: ' + params.address};
        conn.send(JSON.stringify(res));
        return;
    }
    if(params.user) {
        device.setAuth(params.user, params.pass);
    }

    device.init((error, result) => {
        let res = {'id': 'connect'};
        if(error) {
            res['address'] = false
            res['error'] = error.toString();
        } else {
            // res['info'] = result;
            res['address'] = params.address;
            res['user'] = params.user;
            res['pass'] = params.pass;
            res['profile'] = device.getProfileList();
        }
        conn.send(JSON.stringify(res));
    });
}

function fetchSnapshot(conn, params) { // 获取流的帧图片
    let device = devices[params.address];
    if(!device) {
        var res = {'id': 'fetchSnapshot', 'error': 'The specified device is not found: ' + params.address};
        conn.send(JSON.stringify(res));
        return;
    }
    device.fetchSnapshot((error, result) => {
        var res = {'id': 'fetchSnapshot'};
        if(error) {
            res['error'] = error.toString();
        } else {
            var ct = result['headers']['content-type'];
            var buffer = result['body'];
            var b64 = buffer.toString('base64');
            var uri = 'data:' + ct + ';base64,' + b64;
            res['result'] = uri;
        }
        conn.send(JSON.stringify(res));
    });
}

function ptzMove(conn, params) { // 移动球机
    let device = new onvif.OnvifDevice({
        xaddr: params.user.xaddr,
        user: params.user.user,
        pass: params.user.password
    });

    var res = {'id': 'ptzMove'};
    device.init().then(() => {
        device.ptzMove(params.command, (error) => {
            if(error) {
                res['error'] = error.toString();
            } else {
                res['result'] = true;
            }
            conn.send(JSON.stringify(res));
        });
    }).then(() => {
        res['result'] = false;
    }).catch((error) => {
        res['error'] = error.toString();
    });
}

function ptzStop(conn, params) { // 停止球机
    let device = new onvif.OnvifDevice({
        xaddr: params.user.xaddr,
        user: params.user.user,
        pass: params.user.password
    });

    var res = {'id': 'ptzStop'};
    device.init().then(() => {
        device.ptzStop((error) => {
            if(error) {
                res['error'] = error.toString();
            } else {
                res['result'] = true;
            }
            conn.send(JSON.stringify(res));
        });
    }).then(() => {
        res['result'] = false;
    }).catch((error) => {
        res['error'] = error.toString();
    });
}

function ptzHome(conn, params) { // 恢复球机到预置原点
    let device = new onvif.OnvifDevice({
        xaddr: params.user.xaddr,
        user: params.user.user,
        pass: params.user.password
    });

    var res = {'id': 'ptzHome'};
    device.init().then(() => {

        device.services.ptz.gotoHomePosition({
            'ProfileToken': device.getCurrentProfile()['token'],
            'Speed': 1
        }, (error, result) => {
            if(error) {
                res['error'] = error.toString();
            } else {
                res['result'] = true;
            }
            conn.send(JSON.stringify(res));
        });
    }).then(() => {
        res['result'] = false;
    }).catch((error) => {
        res['error'] = error.toString();
    });
}

function getPreset(conn, params) { // 获取预置位
    let device = new onvif.OnvifDevice({
        xaddr: params.user.xaddr,
        user: params.user.user,
        pass: params.user.password
    });

    var res = {'id': 'getPreset'};
    device.init().then(() => {

        device.services.ptz.getPresets({
            'ProfileToken': device.getCurrentProfile()['token']
        }, (error, result) => {
            if(error) {
                res['error'] = error.toString();
            } else {
                res['result'] = result['data'];
            }
            conn.send(JSON.stringify(res));
        });
    }).then(() => {
        res['result'] = false;
    }).catch((error) => {
        res['error'] = error.toString();
    });
}

function setPreset(conn, params) { // 设置预置位
    let device = new onvif.OnvifDevice({
        xaddr: params.user.xaddr,
        user: params.user.user,
        pass: params.user.password
    });

    var res = {'id': 'setPreset'};
    device.init().then(() => {
        device.services.ptz.setPreset({
            'ProfileToken': device.getCurrentProfile()['token'],
            'PresetToken': params.command.PresetToken,
            'PresetName': params.command.PresetName
        }, (error, result) => {
            if(error) {
                res['error'] = error.toString();
            } else {
                res['result'] = result;
            }
            conn.send(JSON.stringify(res));
        });
    }).then(() => {
        res['result'] = false;
    }).catch((error) => {
        res['error'] = error.toString();
    });
}

function gotoPreset(conn, params) { // 移动到预置位
    let device = new onvif.OnvifDevice({
        xaddr: params.user.xaddr,
        user: params.user.user,
        pass: params.user.password
    });

    var res = {'id': 'gotoPreset'};
    device.init().then(() => {

        device.services.ptz.gotoPreset({
            'ProfileToken': device.getCurrentProfile()['token'],
            'PresetToken': params.command.PresetToken,
            'Speed': params.command.Speed
        }, (error, result) => {
            if(error) {
                res['error'] = error.toString();
            } else {
                res['result'] = result;
            }
            conn.send(JSON.stringify(res));
        });
    }).then(() => {
        res['result'] = false;
    }).catch((error) => {
        res['error'] = error.toString();
    });
}

function removePreset(conn, params) { // 删除预置位

}

class OnvifManager {
    init() {
        /**
         * 创建http服务端
         */
        let http_server = http.createServer((request, response) => {
            console.log('onvif.js_ : ', '5001端口开启');
            // console.log(`${new Date().toLocaleDateString()} Received request for ${request.url}`)
            response.writeHead(404)
            response.end()
        });
        http_server.listen(ws_port, function() {
            // console.log(`${new Date().toLocaleDateString()} Received request for ${request.url}`)
        });

        /**
         * 创建websocket服务端
         */
        let ws_server = new WebSocketServer({
            httpServer: http_server,
        });
        ws_server.on('request', wsServerRequest);
    }
}

module.exports = new OnvifManager();

