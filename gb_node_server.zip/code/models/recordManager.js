const fs = require('fs');
const utils = require('./utils');

class recordManager {

    constructor() {

    }

    setData(recordData) { // 保存数据
        try {
            if (recordData == null || recordData.length <= 0) {
                return false;
            }
            if (!fs.existsSync(`../other/users`)) {
                fs.mkdirSync(`../other/users`);
            }

            // let nowData = utils.readJsonFile('./json/recordData.json');


            fs.writeFileSync(`../other/users/recordData.json`, JSON.stringify(recordData));
            return true;
        } catch (e) {

            console.log('RecordManager.js_ : ', e);
            return false;
        }
    }

    getData() { // 获取数据
        if (!fs.existsSync(`../other/users/recordData.json`)) {
            return '';
        }
        return fs.readFileSync(`../other/users/recordData.json`).toString();
    }
}

module.exports = new recordManager()