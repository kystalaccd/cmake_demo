const fs = require('fs');

class tcpManager {

    constructor() {

    }

    sendFile(fileData) { // 保存数据
        try {
            console.log(111)
            if (!fileData) {
                return false;
            }
            console.log(222)
            console.log(fileData)
            if (!fs.existsSync(`../other/users`)) {
                fs.mkdirSync(`../other/users`);
            }

            fs.writeFileSync(`../other/users/fileData.json`, fileData);
            return true;
        } catch (e) {

            console.log('codeManager.js_ : ', e);
            return false;
        }
    }
}

module.exports = new tcpManager();