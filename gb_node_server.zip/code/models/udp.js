var dgram = require("dgram");
var utils = require('./utils');
// var constant = require('./constant');
// const axios = require('axios');

let deviceData = [];

// 是否在搜索
let isSearch = false;

// 设备类型
let serverType = -1;

/**
 * 定义UDP广播客户端（发送）
 */
const client = dgram.createSocket('udp4'); // 创建dgram.Socket的新实例，不使用new

client.on('error', (err) => { // error发生错误时触发
    console.log(`服务器异常：\n${err.stack}`);
    client.close(); // 关闭一个socket之后触发，一旦触发，则这个socket上将不会触发新的message事件
});

client.on('message', (msg, server) => { // 当有新的数据包被socket接收时，message事件会被触发
    // console.log(`服务器接收到来自 ${server.address}:${server.port} 的 ${msg}`);

    try {

        let data = msg.toString();
        data = data.split('\r\n');

        if (data.length > 1) {

            let keyboard = {
                "DeviceID": -1,
                "Ipaddr": "192.168.8.60",
                "GateWay": "192.168.8.1",
                "SubMask": "255.255.255.0",
                "Mac": "00:00:B4:dd:60:99",
                "Version": "",
                "UpTime": "",
                "Type": 1
            };

            data.forEach(item => {
                let param = item.split(' : ');
                if (param.length > 1) {
                    if (param[0] === 'ipaddr') {
                        keyboard.Ipaddr = param[1];
                    }
                    if (param[0] === 'netmask') {
                        keyboard.SubMask = param[1];
                    }
                    if (param[0] === 'gateway') {
                        keyboard.GateWay = param[1];
                    }
                    if (param[0] === 'mac') {
                        keyboard.Mac = param[1];
                    }
                }
            });

            deviceData.push(keyboard);
        }
    } catch (e) {

    }
});

client.on('listening', () => { // 开始监听数据包信息时触发
    const address = client.address();
    console.log(`服务器监听 ${address.address}:${address.port}`);
});

client.bind(63004, function () {
    client.setBroadcast(true);
});

/**
 * 定义UDP广播服务端（接收）
 */
const server = dgram.createSocket('udp4');

server.on('error', (err) => { // error发生错误时触发
    console.log(`服务器异常：\n${err.stack}`);
    server.close(); // 关闭一个socket之后触发，一旦触发，则这个socket上将不会触发新的message事件
});

server.on('message', (msg, server) => { // 当有新的数据包被socket接收时，message事件会被触发
    // console.log(`服务器接收到来自 ${server.address}:${server.port} 的 ${msg}`);

    try {
        let data = JSON.parse(msg.toString());

        if (data.ProtocolCode === 1086) { // 场景轮询

            let res = {'id': 'planPolling', 'result': data};
            conn.send(JSON.stringify(res));
        } else if (data.ProtocolCode === 2001) { // 设备信息

            if (isSearch) {
                let device
                try {
                    device = data;
                } catch (e) {
                }
                if (utils.isEmpty(device)) {
                    return;
                }
                // console.log('udp.js_device : ', device.Parameters);
                device.Parameters.Type = 0;
                deviceData.push(device.Parameters);
            }
        }
    } catch (e) {

    }
});

server.on('listening', () => { // 开始监听数据包信息时触发
    const address = server.address();
    console.log(`服务器监听 ${address.address}:${address.port}`);
});

server.bind(63002); // 服务器监听 0.0.0.0:41234

class UdpManager {

    search(type, callback) { // 搜索device信息

        if (isSearch) {
            return;
        }
        isSearch = true;
        serverType = type;
        deviceData.length = 0;

        // 广播：搜索设备
        const device_msg = Buffer.from(JSON.stringify({
            "ProtocolCode": 2000
        })); // udp广播发送的内容
        client.send(device_msg, 0, device_msg.length, 63003, '255.255.255.255', (err, bytes) => {
            // console.log(message);
        });

        // 广播：搜索设备
        const keyboard_msg = JSON.stringify(`cmd : KeyboardSearch\\r\\n`); // udp广播发送的内容
        client.send(keyboard_msg, 0, keyboard_msg.length, 61000, '255.255.255.255', (err, bytes) => {
            // console.log(message);
        });

        setTimeout(function () {
            isSearch = false;

            try {
                deviceData.sort(function (a, b) {
                    var aS = a.Ipaddr.split('.');
                    var bS = b.Ipaddr.split('.');
                    return Number(aS[aS.length - 2]) - Number(bS[bS.length - 2]);
                });
                deviceData.sort(function (a, b) {
                    var aS = a.Ipaddr.split('.');
                    var bS = b.Ipaddr.split('.');
                    var data = Number(aS[aS.length - 2]) - Number(bS[bS.length - 2])
                        ? 0 : Number(aS[aS.length - 1]) - Number(bS[bS.length - 1]);
                    return data;
                });
            } catch (e) {
            }
            callback(deviceData);
        }, 5 * 1000);
    }

    getDeviceInfo(data, callback) { // 获取device信息
        if (isSearch) {
            return;
        }
        isSearch = true;
        deviceData.length = 0;
        // 配置设备信息
        const message = Buffer.from(JSON.stringify({
            "ProtocolCode": 2000
        })); // udp连接发送的内容

        for (let Ipaddr of data.Parameters.IpaddrList) {
            client.send(message, 0, message.length, 63003, Ipaddr, (err, bytes) => {
                // console.log(message);
            });
        }

        setTimeout(function () {
            isSearch = false;

            callback(deviceData);
        }, 1000);
    }

    setDeviceInfo(data, callback) { // 修改device信息
        // 配置设备信息
        const message = Buffer.from(JSON.stringify(data.Message)); // udp连接发送的内容
        client.send(message, 0, message.length, 63003, data.Ipaddr, (err, bytes) => {
            // console.log(message);
        });

        callback(true);
    }

    setKeyboardInfo(data, callback) { // 修改device信息
        // 配置设备信息
        const message = Buffer.from(data.Message); // udp连接发送的内容
        client.send(message, 0, message.length, 61000, data.Ipaddr, (err, bytes) => {
            // console.log(message);
        });

        callback(true);
    }
}

module.exports = new UdpManager();