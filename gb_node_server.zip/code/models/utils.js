const fs = require('fs')
const path = require('path');
// 使用promisify方法来promise化指定方法
const {promisify} = require('util');
stat = promisify(fs.stat)
readdir = promisify(fs.readdir)

const DecBase64Tab1 = [
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 36, 64, 64, 64, 37, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 64, 64,
    64, 64, 64, 64, 64, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52,
    53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 64, 64, 64, 64, 64, 0, 1, 2, 3,
    4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
    64, 64, 64, 64, 64];

function dec_sef_base64(obuff, olen, ibuff, ilen, iflage) { // 解密接收到的密文
    let cnt = 0
    let ocnt = 0

    if (iflage == 1) {
        tab = 0
    } else if (iflage == 0) {
        tab = 1
    }

    while (cnt + 4 <= ilen & ibuff[cnt] != '\0') {
        let c1 = ibuff[cnt]
        let c2 = ibuff[cnt + 1]
        let c3 = ibuff[cnt + 2]
        let c4 = ibuff[cnt + 3]
        cnt += 4

        if (c1 == '\r') {
            c1 = ibuff[cnt]
            cnt += 1
        }
        if (c1 == '\n') {
            c1 = ibuff[cnt]
            cnt += 1
        }

        if (c2 == '\0' | c3 == '\0' | c4 == '\0') {
            break
        }

        c1 = DecBase64Tab1[c1]
        c2 = DecBase64Tab1[c2]

        obuff[ocnt] = (((c1 << 2) & 0xFF) | ((c2 & 0x30) >> 4))
        ocnt += 1

        if (c3 != '=') {
            c3 = DecBase64Tab1[c3]
            obuff[ocnt] = ((((c2 & 0XF) << 4) & 0xFF) | ((c3 & 0x3C) >> 2))
            ocnt += 1
            if (c4 != '=') {
                c4 = DecBase64Tab1[c4]
                obuff[ocnt] = ((((c3 & 0x03) << 6) & 0xFF) | c4)
                ocnt += 1
            }
        }
    }
    return obuff
}


class Utils {

    // 异步
    async calcSize(dirPath, cb) {
        //单位字节
        let fileSize = 0;
        let error = null

        async function calc(dirPath) {
            try {
                const statObj = await stat(dirPath)
                if (statObj.isDirectory()) {
                    const files = await readdir(dirPath)
                    let dirs = files.map(item => {
                        return path.join(dirPath, item)
                    })
                    let index = 0

                    async function next() {
                        if (index < dirs.length) {
                            let current = dirs[index++]
                            await calc(current)
                            await next()
                        }
                    }

                    return await next()
                } else {
                    fileSize += statObj.size
                }
            } catch (err) {
                error = err
            }
        }

        await calc(dirPath)
        cb(error, fileSize)
    }

    decryptObject(msg) {
        let x = [];
        let y = x.length
        let xx = msg // xx = [ord(i) for i in list(rx_buff.decode('utf-8'))]
        let yy = msg.length
        let list = dec_sef_base64(x, y, xx, yy, 0) // 解密返回的密文数组

        let str = ''
        for (let value of list) {
            if (value == 0) {
                break;
            }
            str += String.fromCharCode(value); // 将对应的ASCII编码值转为字符
        }
        // device_list.push(JSON.parse(str.split('@')[0])) // 将接收到的设备信息放入数组中
        return JSON.parse(str.split('@')[0]);
    }

    isEmpty(val) {
        // null or undefined
        if (val == null) return true;

        if (typeof val === 'boolean') return false;

        if (typeof val === 'number') return !val;

        if (val instanceof Error) return val.message === '';

        switch (Object.prototype.toString.call(val)) {
            // String or Array
            case '[object String]':
            case '[object Array]':
                return !val.length;

            // Map or Set or File
            case '[object File]':
            case '[object Map]':
            case '[object Set]': {
                return !val.size;
            }
            // Plain Object
            case '[object Object]': {
                return !Object.keys(val).length;
            }
        }
        return false;
    }

    //获取客户端真实ip;
    getClientIP(req) {
        var ipAddress;
        try {
            var forwardedIpsStr = req.headers['X-Forwarded-For'];//判断是否有反向代理头信息
            if (forwardedIpsStr) {//如果有，则将头信息中第一个地址拿出，该地址就是真实的客户端IP；
                var forwardedIps = forwardedIpsStr.split(',');
                ipAddress = forwardedIps[0];
            }
            if (!ipAddress) {//如果没有直接获取IP；
                ipAddress = req.connection.remoteAddress;
            }
        } catch (e) {
            ipAddress = '0.0.0.0';
        }
        return ipAddress;
    }
}


module.exports = new Utils();
