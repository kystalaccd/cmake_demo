var express = require('express');
var router = express.Router();
var codeManager = require('../models/codeManager');

/* GET home page. */
router.post('/setCode', function(req, res, next) {

    var state = 400;
    var msg = '保存失败';
    try {
        if (codeManager.setData(req.body.codeData)) {
            state = 200;
            msg = '保存成功';
        }
    } finally {
        res.json({
            status: state,
            msg: msg
        });
        return
    }
});

router.post('/getCode', function(req, res, next) {

    var state = 400;
    var msg = '获取失败';
    var codeData = "";
    try {
        codeData = codeManager.getData();
        if (!codeData.startsWith('undefined')) {
            state = 200;
            msg = '获取成功';
        }
        codeData = JSON.parse(codeData);
    } finally {
        res.json({
            status: state,
            msg: msg,
            data: codeData
        });
        return
    }
});

/* GET home page. */
router.post('/setQRCode', function(req, res, next) {

    var state = 400;
    var msg = '保存失败';
    try {
        if (codeManager.setQRCodeData(req.body.QRCodeData)) {
            state = 200;
            msg = '保存成功';
        }
    } finally {
        res.json({
            status: state,
            msg: msg
        });
        return
    }
});

router.post('/getQRCode', function(req, res, next) {

    var state = 400;
    var msg = '获取失败';
    var QRCodeData = "";
    try {
        QRCodeData = codeManager.getQRCodeData();
        if (!QRCodeData.startsWith('undefined')) {
            state = 200;
            msg = '获取成功';
        }
        QRCodeData = JSON.parse(QRCodeData);
    } finally {
        res.json({
            status: state,
            msg: msg,
            data: QRCodeData
        });
        return
    }
});

module.exports = router