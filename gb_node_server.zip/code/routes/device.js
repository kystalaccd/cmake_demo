var express = require('express');
var udpManager = require('../models/udp');
var router = express.Router();

/* GET home page. */
router.post('/search', function(req, res, next) {
    udpManager.search(req.body, function (data) {
        res.json({
            status: 200,
            msg: '成功',
            data: data
        });
        return
    })
});

router.post('/getDeviceInfo', function(req, res, next) {
    udpManager.getDeviceInfo(req.body, function (data) {
        res.json({
            status: 200,
            msg: '成功',
            data: data
        });
        return
    })
});

router.post('/setDeviceInfo', function(req, res, next) {
    udpManager.setDeviceInfo(req.body, function (data) {
        res.json({
            status: 200,
            msg: '成功',
            data: data
        });
        return
    })
});

router.post('/setKeyboardInfo', function(req, res, next) {
    udpManager.setKeyboardInfo(req.body, function (data) {
        res.json({
            status: 200,
            msg: '成功',
            data: data
        });
        return
    })
});


module.exports = router


