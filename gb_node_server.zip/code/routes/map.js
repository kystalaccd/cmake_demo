var express = require('express');
var router = express.Router();
var mapManager = require('../models/mapManager');

/* GET home page. */
router.post('/setData', function(req, res, next) {

    var state = 400;
    var msg = '保存失败';
    try {
        if (mapManager.setData(req.body.mapData)) {
            state = 200;
            msg = '保存成功';
        }
    } finally {
        res.json({
            status: state,
            msg: msg
        });
        return
    }
});

router.post('/getData', function(req, res, next) {

    var state = 400;
    var msg = '获取失败';
    var mapData = "";
    try {
        mapData = mapManager.getData();
        if (mapData.length > 0 && !mapData.startsWith('undefined')) {
            state = 200;
            msg = '获取成功';
        }
        mapData = JSON.parse(mapData);
    } finally {
        res.json({
            status: state,
            msg: msg,
            data: mapData
        });
        return
    }
});

module.exports = router