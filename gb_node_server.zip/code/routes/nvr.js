var express = require('express');
var nvrManager = require('../models/nvrManager');
var router = express.Router();

/* GET home page. */
router.post('/save', function(req, res, next) {

  var state = 400;
  var msg = '保存失败';
  try {
    if (nvrManager.save(req.body.nvrData)) {
      state = 200;
      msg = '保存成功';
    }
  } finally {
    res.json({
      status: state,
      msg: msg
    });
    return
  }
});

router.post('/getData', function(req, res, next) {

  var state = 400;
  var msg = '获取失败';
  var nvrData = "";
  try {
    nvrData = nvrManager.getData();
    if (nvrData.length > 0 && !nvrData.startsWith('undefined')) {
      state = 200;
      msg = '获取成功';
    }
    nvrData = JSON.parse(nvrData);
  } finally {

    res.json({
      status: state,
      msg: msg,
      data: nvrData
    });
    return
  }
});

router.post('/delete', function(req, res, next) {

  var state = 400;
  var msg = '删除失败';
  try {
    if (nvrManager.delete(req.body.ids)) {
      state = 200;
      msg = '删除成功';
    }
  } finally {
    res.json({
      status: state,
      msg: msg
    });
    return
  }
});

module.exports = router
