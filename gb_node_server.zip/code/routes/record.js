var express = require('express');
var router = express.Router();
var recordManager = require('../models/recordManager');

/* GET home page. */
router.post('/setData', function(req, res, next) {

    var state = 400;
    var msg = '保存失败';
    try {
        if (recordManager.setData(req.body.recordData)) {
            state = 200;
            msg = '保存成功';
        }
    } finally {
        res.json({
            status: state,
            msg: msg
        });
        return
    }
});

router.post('/getData', function(req, res, next) {

    var state = 400;
    var msg = '获取失败';
    var recordData = "";
    try {
        recordData = recordManager.getData();
        if (recordData.length > 0 && !recordData.startsWith('undefined')) {
            state = 200;
            msg = '获取成功';
        }
        recordData = JSON.parse(recordData);
    } finally {
        res.json({
            status: state,
            msg: msg,
            data: recordData
        });
        return
    }
});

module.exports = router