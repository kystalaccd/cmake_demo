var express = require('express');
var router = express.Router();
var tcpManager = require('../models/tcp');

/* GET home page. */
router.post('/upload', function(req, res, next) {

    var state = 400;
    var msg = '传输失败';
    try {
        console.log(110)
        console.log(req)
        if (tcpManager.sendFile(req.body)) {
            state = 200;
            msg = '传输成功';
        }
    } finally {
        res.json({
            status: state,
            msg: msg
        });
        return
    }
});

module.exports = router