$(function () {
    $("#platform_menu").click(function () { // 平台配置

        $(".nav").css({
            "border-bottom": "1px solid #B3B3B5",
            "background-image": "linear-gradient(#F4F5F7, #CDD4DA)"
        });

        $("#platform_menu").css({
            "border-bottom": "none",
            "background-image": "linear-gradient(#F4F5F7, #F4F5F7)"
        });

        $(".config-wrap").hide();
        $("#platform_config").show();
    });

    $("#network_menu").click(function () { // 网络配置

        $(".nav").css({
            "border-bottom": "1px solid #B3B3B5",
            "background-image": "linear-gradient(#F4F5F7, #CDD4DA)"
        });

        $("#network_menu").css({
            "border-bottom": "none",
            "background-image": "linear-gradient(#F4F5F7, #F4F5F7)"
        });

        $(".config-wrap").hide();
        $("#network_config").show();
    });


    $("input").on("input",(e) => { // 去掉所有输入框前后的空格
        if (e.target.type !== 'file') {
            e.target.value = e.target.value.replace(/(^\s*)|(\s*$)/g, "")
        }
    });
});

function initBoard() { // 初始化设备相关参数信息
    $("#platform_menu").click();
}
//
// function initGetCameraList(callback) {
//     $.ajax({
//         type: 'post',
//         url: `http://${MAIN_HOST}:${MAIN_PORT}`,
//         data: JSON.stringify({
//             "ProtocolCode": 1016
//         }),
//         contentType: 'application/x-www-form-urlencoded',
//         dataType: 'json',
//         success: function (data) {
//             ipc_list = data.Parameters;
//
//             nvr_list.length = 0;
//             camera_list.length = 0;
//
//             ipc_list.forEach(item => {
//                 item.Type === 2 ?
//                     nvr_list.push(item) : camera_list.push(item)
//             })
//
//             if (callback) {
//                 callback()
//             } else {
//                 ipcRefreshInfo() // 获取ipc信息
//             }
//         },
//         error: function () {
//             toastr.error("请求出错！");
//         }
//     });
// }