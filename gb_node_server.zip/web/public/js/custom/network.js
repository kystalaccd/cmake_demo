let network_list = [];

function networkInit() { // 初始化网络参数
    networkShowDeviceIP()
    networkShowDeviceInfo()
}

function networkShowDeviceIP() {
    content = ''

    device_list.forEach((item, index) => {
        content += '<option>'+ item.Ipaddr + '</option>'
    })
    $("#network_device_num").empty().append(content);
}

function networkShowDeviceInfo() { // 切换网络配置信息

    let ip = $("#network_device_num").val();
    let device_info = device_list.find(item => item.Ipaddr === ip);

    $("#network_ip").val(device_info.Ipaddr);
    $("#network_mac").val(device_info.Mac);
    $("#network_netmask").val(device_info.SubMask);
    $("#network_gateway").val(device_info.GateWay);
}

function networkChoiceDNSServer(dom) { // 首选DNS服务器
    if ($(dom).prop('checked')) {
        $("#network_main_dns").val('114.114.114.114');
        $("#network_second_dns").val('8.8.8.8');
    } else {
        $("#network_main_dns").val('');
        $("#network_second_dns").val('');
    }
}

function networkRefreshInfo() { // 刷新网络配置信息
    decodingGetAlreadyDevice(function () {
        networkInit();
    })
}

function networkSubmitInfo() { // 提交网络配置信息

    let ip = $("#network_device_num").val();
    let device_info = device_list.find(item => item.Ipaddr === ip);

    $.ajax({
        type: 'post',
        url: `http://${SERVER_HOST}:${SERVER_PORT}/device/setDeviceInfo`,
        data: JSON.stringify({
            Message: {
                "ProtocolCode": 2002,
                "Parameters":{
                    "DeviceID": device_info.DeviceID,
                    "Width": device_info.Width,
                    "Height": device_info.Height,
                    "Fresh_Freq": device_info.Fresh_Freq,
                    "Eth": device_info.Eth,
                    "Ipaddr": $("#network_ip").val(),
                    "SubMask": $("#network_netmask").val(),
                    "GateWay": $("#network_gateway").val(),
                    "Mac": $("#network_mac").val()
                }
            },
            Ipaddr: ip
        }),
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (data) {
            if (data.data) {
                toastr.success("网络修改成功！");
            }
        },
        error: function () {
            toastr.error("请求出错！");
        }
    });
}