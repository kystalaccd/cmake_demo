function systemInit() { // 初始化系统配置页面

    systemGetSoftwareInfo(); // 获取版本信息
    systemGetQRCodeInfo(); // 获取二维码信息
    systemGetStreamInfo(); // 获取码流信息（主/次）
    systemGetDeviceScreenOSD(); // 获取设备幕墙配置
}

function systemGetSoftwareInfo() { // 获取软件版本信息
    let software = 'V1.0.1 Build 202305061645';
    let explain = `1.新增升级功能，还在开发中；\n
        2.修改拼接预案的方式；\n
        3.调整左侧边栏IPC信息列表；\n
        4.退出漫游，要检测把漫游窗口发指令关闭；\n
        5.在监控点树列表的位置增加查询功能；`;

    $("#software_edition").val(software);
    $("#software_explain").val(explain);

    $("#software_number").text(software);
}

function systemGetStreamInfo() { // 获取码流信息（主/次）

    $("#code_stream").val(codeData.codeStream);
}

function systemSetStreamInfo(value) { // 设置码流信息（主/次）

    codeData.codeStream = value;

    $.ajax({
        type: 'post',
        url: `http://${SERVER_HOST}:${SERVER_PORT}/code/setCode`,
        data: JSON.stringify({
            codeData: codeData
        }),
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (data) {

            if (data.status == 200) {

                toastr.success('码流切换成功！');
            }
        },
        error: function () {
            toastr.error("请求出错！");
        }
    });
}

function systemGetQRCodeInfo() { // 获取设备二维码信息
    let device = device_list.find(item => item.DeviceID === 0);

    if (device) {

        if (device.Ipaddr === SERVER_HOST) {

            let image = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAAGQCAIAAAAP3aGbAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHv0lEQVR4nO3d0W0bQRAFQdFQ/inLCRjwAl6Mp++qAuCRotjYn4f9/Pz8fAEU/PrfbwDglGABGYIFZAgWkCFYQIZgARmCBWQIFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZAgWkCFYQIZgARmCBWQIFpAhWECGYAEZggVkfN96oc/nc+ulik6ud9z2Jxp+z8UbME8+fvGrH3bxq3fCAjIEC8gQLCBDsIAMwQIyBAvIECwgQ7CADMECMgQLyBAsIOPalvDEU9dkh26Nzm69zq1nHZrc00X3fS//gZxwwgIyBAvIECwgQ7CADMECMgQLyBAsIEOwgAzBAjIEC8gQLCBjdEt4Ytvi7MEmt40XH3fiwfcJvvwH4oQFZAgWkCFYQIZgARmCBWQIFpAhWECGYAEZggVkCBaQIVhAxrot4YNtG7gtHMrdMjyTZIwTFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZAgWkCFYQIZgARm2hHOiF+H91cX3fOtPtO1+Q25xwgIyBAvIECwgQ7CADMECMgQLyBAsIEOwgAzBAjIEC8gQLCBj3Zbw5cusWx9/4Qju1r5v8s7BhdPOl/9AnLCADMECMgQLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvIGN0SLlxmTZocuG17neG3FPXyH8gJJywgQ7CADMECMgQLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvI+Dx4Ssq/uzjHLf6nvXyMvZATFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZAgWkCFYQIZgARmjF6meGL7d85Ztb2nhraW3Pv627d7CveHkWxr++E5YQIZgARmCBWQIFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZFy7l3ByKbZtlPfVnEAOv5/Jx237Ux+aXIAunECecMICMgQLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvIECwg49q9hAtnR1ccLs62DeUWKs4tb7m4SN3GvYQAfyZYQIZgARmCBWQIFpAhWECGYAEZggVkCBaQIVhAhmABGde2hNsu1BtWXIGduPin3nbn4LbXOTT5uIX/1U5YQIZgARmCBWQIFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZHxujcW2ra4evPDaNoIbnnYuHLj91fAkc9v1ju4lBN5IsIAMwQIyBAvIECwgQ7CADMECMgQLyBAsIEOwgAzBAjJGt4QnHjxw27Y3vGV4kjlp4W4x+gO5xQkLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvIECwgQ7CAjO/JhxVnUMNrsm0fLTrJnHzWwtstiz+0Q05YQIZgARmCBWQIFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZAgWkHHtItVJD95/brtI9eKf6MHf2jbbdt0Xvw4nLCBDsIAMwQIyBAvIECwgQ7CADMECMgQLyBAsIEOwgAzBAjKuXaS6bXY0PKeKLrNWPevQy++avWX4huBbnLCADMECMgQLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvIuLYl3LYB3PasQ8VNYnRuufDbf/nHP+GEBWQIFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZAgWkCFYQMZn2y4vel3aieLC6+L72fbNFr+OQ8U/9SEnLCBDsIAMwQIyBAvIECwgQ7CADMECMgQLyBAsIEOwgAzBAjKubQmPHjY4cRpeim27TnGh4mp14X/RiQfPJJ2wgAzBAjIEC8gQLCBDsIAMwQIyBAvIECwgQ7CADMECMgQLyFh3L+EtL78n8alf61f2G5lU/KEdcsICMgQLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvIECwgY/RewpebvHXuRHRuue16x+iUcvKbtSUE3kiwgAzBAjIEC8gQLCBDsIAMwQIyBAvIECwgQ7CADMECMr5vvdDLb4s7WUtNrrcmb4u7uBSb/PiTDt/P5DeycCd4wgkLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvIECwgQ7CADMECMq6Nn08UL229OKOdHCTfcvHj39qH33rW5EB64WWr2/7TDjlhARmCBWQIFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZAgWkDG6JTzx4IXXickV2K1nbbu1dNjCj3/rW5t8nUNOWECGYAEZggVkCBaQIVhAhmABGYIFZAgWkCFYQIZgARmCBWSs2xI+2OR08cEzyVvbvZfPJBfuBE84YQEZggVkCBaQIVhAhmABGYIFZAgWkCFYQIZgARmCBWQIFpBhSzjHnYNjj9u2STx06y1t+zO6lxB4I8ECMgQLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvIWLclXHih3i0Ll1lXnnW4XJvc901OIC8+a3JJeut13EsI8GeCBWQIFpAhWECGYAEZggVkCBaQIVhAhmABGYIFZAgWkDG6JRy+5K5o212BF9dkk1clTg7cFl7duG226V5C4I0EC8gQLCBDsIAMwQIyBAvIECwgQ7CADMECMgQLyBAsIOPz4HsAgYdxwgIyBAvIECwgQ7CADMECMgQLyBAsIEOwgAzBAjIEC8gQLCBDsIAMwQIyBAvIECwgQ7CADMECMgQLyBAsIEOwgAzBAjIEC8gQLCBDsICM358OWEdKS0afAAAAAElFTkSuQmCC`

            $("#qr_code").prop('src', image);

            $.ajax({
                type: 'post',
                url: `http://${SERVER_HOST}:${SERVER_PORT}/code/getQRCode`,
                data: JSON.stringify({}),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (data) {
                    if (data.status === 200) {

                        if (data.data.QRCode) {
                            $("#qr_code").prop('src', data.data.QRCode);
                        }
                    }
                }
            });

            return
        }
    }

    $("#qr_code").css('display', 'none');
}

// 双击上传图片
function systemSetQRCodeInfo(dom) {
    $(dom).next().click();
}

function systemChoiceImage(file) {
    let fileData = file.files[0];

    if (fileData.type.split('/')[0] === 'image') {

        const reader = new FileReader();
        reader.onload = function (e) {

            const image = new Image();
            image.src = e.target.result;

            $.ajax({
                type: 'post',
                url: `http://${SERVER_HOST}:${SERVER_PORT}/code/setQRCode`,
                data: JSON.stringify({
                    QRCodeData: {
                        QRCode: e.target.result
                    }
                }),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (data) {

                    if (data.status == 200) {

                        toastr.success('图片上传成功！');
                        systemGetQRCodeInfo();
                    }
                },
                error: function () {
                    toastr.error("请求出错！");
                }
            });
        };
        reader.readAsDataURL(fileData);
    } else {
        toastr.warning('请上传图片格式！');
    }
}

function systemCalibrateTime() {
    setTimeout(function () {
        toastr.success('设备时间校准成功！');
    }, 200);
}

function systemRestart() { // 重启设备

    // 获取当前板卡的设备信息
    let device = device_list.find(item => item.Ipaddr === SERVER_HOST);

    layer.confirm('将重启设备，是否确定？', function (sample) {
        layer.close(sample);

        $.ajax({
            type: 'post',
            url: `http://${MAIN_HOST}:${MAIN_PORT}`,
            data: JSON.stringify({
                "ProtocolCode": 1052,
                "Parameters": {
                    "Device_Id": device.DeviceID
                }
            }),
            contentType: 'application/x-www-form-urlencoded',
            dataType: 'json',
            success: function (data) {
                if (data.Parameters === 1) {
                    toastr.success('设备重启中...');
                }
            },
            error: function () {
                toastr.error("请求出错！");
            }
        });
    });
}

function systemClearFileInfo() { // 初始化设备数据
    // layer.confirm('将初始化设备数据，是否确定？', function (sample) {
    //     layer.close(sample);
    //
    //     $.ajax({
    //         type: 'post',
    //         url: 'http://' + DEVICE_IP + ':5000/api/deleteAllFileInfo',
    //         data: JSON.stringify({}),
    //         contentType: 'application/json; charset=utf-8',
    //         dataType: 'json',
    //         success: function (data) {
    //             if (data.code === 200) {
    //                 toastr.success('初始化成功！')
    //             } else {
    //                 toastr.error('初始化失败！')
    //                 console.log(data.error)
    //             }
    //         },
    //         error: function () {
    //             toastr.error("请求出错！");
    //         }
    //     });
    // });
}

function systemGetDeviceScreenOSD() { // 获取设备幕墙OSD信息
    $.ajax({
        type: 'post',
        url: `http://${MAIN_HOST}:${MAIN_PORT}`,
        data: JSON.stringify({
            "ProtocolCode": 1070
        }),
        contentType: 'application/x-www-form-urlencoded',
        dataType: 'json',
        success: function (data) {
            if (data.Parameters) {
                let device_screen_params = document.getElementsByName('device_screen_param');

                device_screen_params[0].checked = data.Parameters.LineStatus === 1 ? true : false;
                device_screen_params[1].checked = data.Parameters.ChnStatus === 1 ? true : false;
                device_screen_params[2].checked = data.Parameters.IpcStatus === 1 ? true : false;
                device_screen_params[3].checked = data.Parameters.ScreenNumStatus === 1 ? true : false;
            }
        },
        error: function () {
            toastr.error("请求出错！");
        }
    });
}

function systemSetDeviceScreen() {
    let param = {
        "LineStatus": 1,
        "ChnStatus": 1,
        "IpcStatus": 1,
        "ScreenNumStatus": 1
    }

    $("input[name='device_screen_param']").each(function (i, item) {
        switch (i) {
            case 0:
                param.LineStatus = $(item).prop('checked') ? 1 : 0
                break;
            case 1:
                param.ChnStatus = $(item).prop('checked') ? 1 : 0
                break;
            case 2:
                param.IpcStatus = $(item).prop('checked') ? 1 : 0
                break;
            case 3:
                param.ScreenNumStatus = $(item).prop('checked') ? 1 : 0
                break;
        }
    });

    $.ajax({
        type: 'post',
        url: `http://${MAIN_HOST}:${MAIN_PORT}`,
        data: JSON.stringify({
            "ProtocolCode": 1068,
            "Parameters": param
        }),
        contentType: 'application/x-www-form-urlencoded',
        dataType: 'json',
        success: function (data) {
            if (data.Parameters === 1) {
                toastr.success("设备OSD显示配置成功！");
            }
        },
        error: function () {
            toastr.error("请求出错！");
        }
    });
}

function systemShowDeviceScreenCaptions() { // 显示设备幕墙字幕信息
    systemGetDeviceScreenCaptions(function (info) {

        layer.open({
            type: 1, // Layer提供了5种层类型。可传入的值有：0（信息框，默认），1（页面层），2（iframe层），3（加载层），4（tips层）。
            shade: 0.1, // 遮罩层透明度
            area: ['800px', '300px'], // 弹出层宽高
            title: '幕墙字幕', // 弹出层标题
            content: '<div class="model-body">' +
                '<div class="model-item">' +
                '<label name="captions_show">打开状态：</label>' +
                '<input id="captions_show" type="text" style="margin-right: 78%;width: 10%;" readonly />' +
                '</div>' +
                '<div class="model-item">' +
                '<label name="captions_speed">播放速率：</label>' +
                '<select id="captions_speed">' +
                '<option value="0">0</option>' +
                '<option value="1">1</option>' +
                '<option value="2">2</option>' +
                '<option value="3">3</option>' +
                '<option value="4">4</option>' +
                '<option value="5">5</option>' +
                '<option value="6">6</option>' +
                '</select>' +
                '</div>' +
                '<div class="model-item">' +
                '<label name="captions_word">字幕文本：</label>' +
                '<input id="captions_word" type="text" value="' + info.Word + '" />' +
                '</div>' +
                '</div>',
            btn: ['打开', '关闭'], // 按钮组
            scrollbar: false, // 屏蔽浏览器滚动条
            btnAlign: 'c',
            yes: function (sample) {
                $.ajax({
                    type: 'post',
                    url: `http://${MAIN_HOST}:${MAIN_PORT}`,
                    data: JSON.stringify({
                        "ProtocolCode": 1072,
                        "Parameters": {
                            "Speed": Number($("#captions_speed").val()),
                            "Word": $("#captions_word").val(),
                            "OpenStatus": 1
                        }
                    }),
                    contentType: 'application/x-www-form-urlencoded',
                    dataType: 'json',
                    success: function (data) {
                        if (data.Parameters) {
                            toastr.success('幕墙字幕打开成功！');

                            layer.close(sample);
                        }
                    },
                    error: function () {
                        toastr.error("请求出错！");
                    }
                });
            },
            btn2: function () {
                $.ajax({
                    type: 'post',
                    url: `http://${MAIN_HOST}:${MAIN_PORT}`,
                    data: JSON.stringify({
                        "ProtocolCode": 1072,
                        "Parameters": {
                            "Speed": 0,
                            "Word": '',
                            "OpenStatus": 0
                        }
                    }),
                    contentType: 'application/x-www-form-urlencoded',
                    dataType: 'json',
                    success: function (data) {
                        if (data.Parameters) {
                            toastr.success('幕墙字幕关闭成功！');
                        }
                    },
                    error: function () {
                        toastr.error("请求出错！");
                    }
                });
            }
        });

        $("#captions_speed").val(info.Speed);
        $("#captions_show").val(info.OpenStatus === 0 ? '未打开' : '已打开')
    })
}

function systemGetDeviceScreenCaptions(callback) { // 获取设备幕墙字幕信息
    $.ajax({
        type: 'post',
        url: `http://${MAIN_HOST}:${MAIN_PORT}`,
        data: JSON.stringify({
            "ProtocolCode": 1074
        }),
        contentType: 'application/x-www-form-urlencoded',
        dataType: 'json',
        success: function (data) {
            if (data.Parameters) {
                callback(data.Parameters)
            }
        },
        error: function () {
            toastr.error("请求出错！");
        }
    });
}

let req_count = 0;
function systemGetProbationPeriod(callback) { // 获取试用时间
    if (req_count < 2) {

        req_count++;

        $.ajax({
            type: 'post',
            url: `http://${MAIN_HOST}:1000/api/trial`,
            data: JSON.stringify({
                "Protocolcode": 1096
            }),
            contentType: 'application/x-www-form-urlencoded',
            timeout: 500,
            success: function (data) {

                if ('trialTime' in data.Parameters) {

                    if (data.Parameters.trialTime === 'unlock') {

                        $("#probation_period_checkbox").attr('checked', true);
                        $("#probation_period").val(90);
                    } else {

                        $("#probation_period_checkbox").attr('checked', false);
                        $("#probation_period").val(data.Parameters.trialTime / (60 * 24));
                    }

                    callback(data)
                }
            },
            error: function (request, status) {

                if (status === 'timeout') {
                    systemGetProbationPeriod(callback);
                }
            }
        });
    }
}

$("#set_probation_period").click(function () {

    req_count = 0;
    systemSetProbationPeriod();
})

function systemSetProbationPeriod() {
    if (req_count < 2) {

        req_count++;

        let time = $("#probation_period_checkbox").prop('checked') ?
            'unlock' : Number($("#probation_period").val()) * 60 * 24;

        $.ajax({
            type: 'post',
            url: `http://${MAIN_HOST}:1000/api/trial`,
            data: JSON.stringify({
                "ProtocolCode": 1094,
                "Parameters": {
                    "time": time,
                    "checkCode": codeData.verifyCode
                }
            }),
            contentType: 'application/x-www-form-urlencoded',
            timeout: 500,
            success: function (data) {

                if (data.Parameters.status === 'erro') {
                    toastr.error('系统试用时间设置失败！');
                } else {
                    toastr.success('系统试用时间设置成功！');
                }
            },
            error: function (request, status) {

                if (status === 'timeout') {
                    systemSetProbationPeriod();
                }
            }
        });
    }
}