function utilsRandom(lower, upper) {                // 生成随机数
    return Math.floor(Math.random() * (upper - lower)) + lower;
}

function utilsNowTimeStamp() {                      // 获取当前时间戳
    return (new Date() / 1000);
}

function utilsNowTime() {                           // 获取当前时间
    return utilsTransformByTime(utilsNowTimeStamp());
}

function utilsTransformByDate(timestamp) {          // 时间戳转日期
    let date = new Date(timestamp * 1000);

    return utilsCompareSize(date.getFullYear()) + "-" +
        utilsCompareSize(date.getMonth() + 1) + "-" +
        utilsCompareSize(date.getDate());
}

function utilsTransformByTime(timestamp) {          // 时间戳转时间
    let date = new Date(timestamp * 1000);
    return utilsCompareSize(date.getFullYear()) + "-" +
        utilsCompareSize(date.getMonth() + 1) + "-" +
        utilsCompareSize(date.getDate()) + " " +
        utilsCompareSize(date.getHours()) + ":" +
        utilsCompareSize(date.getMinutes()) + ":" +
        utilsCompareSize(date.getSeconds());
}

function utilsTransformByTimeStamp(time) {           // 时间转时间戳
    return (Date.parse(new Date(time)) / 1000);
}

function utilsCompareSize(target) {                 // 时分秒数字为个位数，在十位添0
    return target < 10 ? '0' + target : target;
}

function utilsDurationOfTimeStamp(start, stop) {    // 根据时间戳算出时分秒
    // eslint-disable-next-line no-unused-vars
    let long = null
    let h, min
    start < stop ? long = stop - start : long = start - stop
    if (long > 3600) {
        h = Math.floor(long / 3600)
        min = Math.floor((long % 3600) / 60)
        return h + 'h' + min + 'min'
    } else {
        min = Math.floor(long / 60)
        return min + 'min'
    }
}

function utilsIsMobile() {                          // 当前设备是否为移动设备
    let flag = navigator.userAgent.match(
        /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
    );
    return flag;
}