
// const SERVER_HOST = window.location.hostname;
const SERVER_HOST = window.location.hostname;
const SERVER_PORT = '5000';
const SERVER_WS_PORT = '5001';

const MAIN_HOST = '192.168.8.60';
// const MAIN_HOST = window.location.hostname;
const MAIN_PORT = '6001';
const MAIN_GB_PORT = '8888';

function requestAsyncThread(url, data, callback) {
    $.ajax({
        type: 'post',
        url: url + ':8007/cgi-bin/web_function.cgi',
        data: JSON.stringify(data),
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        async: true,
        success: function (data) {
            callback(data)
        },
        error: function () {
            toastr.error("请求出错！");
        }
    });
}

function requestReaderFile(url, callback) {
    $.ajax({
        type: 'get',
        url: url,
        success: function (data) {
            callback(JSON.parse(data))
        },
        error: function () {
            toastr.warning("文件读取异常！");
        }
    });
}
